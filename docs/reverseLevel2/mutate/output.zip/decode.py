s = ""
flag = ""
for i in range(0, len(s), 2) : 
  flag += chr(int('0x'+s[i:i+2], 16) ^ (32 + (i / 2)))
print flag