from pwn import *

r = remote('140.110.112.29', 5119)
for x in range(3):
  r.recvline()

for x in range(100):
  r.recvline()
  q = r.recvline()
  r.recvuntil(')?')
  arr = q.split()
  if(int(arr[0]) + int(arr[2]) == int(arr[4])) :
    r.sendline("+")
  elif(int(arr[0]) - int(arr[2]) == int(arr[4])) :
    r.sendline("-")
  else :
    r.sendline("*")
print r.recvline()


