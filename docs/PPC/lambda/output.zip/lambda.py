from pwn import *

def f0(x) :
  return (3 * x * x) + x + 3

def f1(x) :
  return (5 * x * x) + 8

def f2(x) :
  return (4 * x * x * x) + 6 * x + 6

def f3(x) :
  return (7 * x * x * x) + (5 * x * x)

def f4(x) :
  return (x * x) + (4 * x) + 3

r = remote('140.110.112.29', 5124)
for x in range(12):
  r.recvline()
for x in range(100):
  r.recvline()
  f = r.recvline()
  search = re.search(': (\d*)', f, re.IGNORECASE)
  f = search.group(1)
  x = r.recvline()
  search = re.search('= (\d*)', x, re.IGNORECASE)
  x = search.group(1)

  if(f == "0") :
    a = f0(int(x))
  elif(f == "1") :
    a = f1(int(x))
  elif(f == "2") :
    a = f2(int(x))
  elif(f == "3") :
    a = f3(int(x))
  elif(f == "4") :
    a = f4(int(x))
  r.sendline(str(a))
  
print r.recvline()
