#!/usr/bin/env python2
from pwn import *
import re

r = remote('140.110.112.29', 5126)
for x in range(10):
  r.recvline()

flag = ""
board = {0:0, 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0, 8:0}
firstLine = 0
waveC = 0

while True :
  lines = r.recvuntil('your move :')
  lines = lines.split("\n")
  for line in lines :
    #print line
    if (re.match('----- wave', line) != None) :
      waveC += 1
      # print line
      board = {0:0, 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0, 8:0}
      firstLine = 1
      continue
    if (re.match('ai move : ', line) != None) :
      place = line.split()
      board[int(place[3])] = -1
      if (firstLine == 1) :
        flag = flag + str(place[3])
        firstLine = 0
  if (waveC == 121 and firstLine == 0) :
    break
  # print board
  for k, v in board.items() :
    if(v == 0) :
      r.sendline(str(k))
      board[k] = 1
      break; 
  # print board
print flag