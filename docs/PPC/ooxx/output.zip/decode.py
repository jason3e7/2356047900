#!/usr/bin/env python3
def base(n, x):
  ans = []
  while n > 0:
    ans.append(n % x)
    n //= x
  return ans

# reverse
def debase(n, x):
  count = 0
  base = 1
  for c in n :
    num = int(c)
    count = count + (num * base)
    base = base * x
  return count

'''
# test case 1
test = 2147483647
print(test)

flag = base(test, 9)
s = ""
for x in flag :
  s = s + str(x)
print(s)

s = debase(s, 9)
print(s)

# test case 2
flag = b'Test Case 2'
print(flag)
print(int.from_bytes(flag, 'big'))
print(base(int.from_bytes(flag, 'big'), 9))
flag = base(int.from_bytes(flag, 'big'), 9)

s = ""
for x in flag :
  s = s + str(x)
print(s)

print(debase(s, 9))
print(debase(s, 9).to_bytes(100, 'big'))
print(debase(s, 9).to_bytes(100, 'big').decode())
'''

flag = ""
print(debase(flag, 9).to_bytes(100, 'big').decode())

