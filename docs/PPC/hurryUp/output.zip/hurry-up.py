from pwn import *

def getStr(sign, shift, string) :
  output = ""
  for x in string :
    temp = ord(x)
    if('A' <= x and x <= 'Z') :
      if(sign == "+") :
        temp = temp + int(shift)
      else :
        temp = temp - int(shift)
      if(temp >= 91) :
        temp = temp - 91 + 65
      if(temp <= 64) :
        temp = temp - 64 + 90
    output = output + chr(temp)
  return output  

r = remote('140.110.112.29', 5123)
r.recvline()
for x in range(100):
  r.recvline()
  q = r.recvline()
  search = re.search('(-|\+)(\d*) : (.*)', q, re.IGNORECASE)
  r.sendline(getStr(search.group(1), search.group(2), search.group(3)))
print r.recvline()