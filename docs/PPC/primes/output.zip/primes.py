from pwn import *
import sympy

def checkPrime(num) :
  return sympy.isprime(num)

def countNum(num) :
  c = 0
  while(num > 0) :
    c += (num % 10)
    num /= 10
  return c

def getNum(length) :
  b = (10 ** (int(length) - 1))+1
  while True :
    flag = checkPrime(countNum(b))
    if (flag) :
      flag = checkPrime(b)
    if (flag) :
      return b
    b += 2

r = remote('140.110.112.29', 5131)
for x in range(7):
  r.recvline()

for x in range(100):
  r.recvline()
  s = r.recvline()
  s = s.split()
  a = str(getNum(int(s[2])))
  r.sendline(a)
print r.recvline()

