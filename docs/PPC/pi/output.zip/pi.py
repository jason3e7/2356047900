from pwn import *

def pi(n):
  p = 10 ** (n + 10)
  a = p * 16 // 5
  b = p * 4 // -239
  f = a + b
  p = f 
  j = 3             
  while abs(f):
    a //= -25
    b //= -57121
    f = (a + b) // j
    p += f
    j += 2
  return p // (10 ** 10)

ans = pi(150)
'''
round, but
31, 3.141592653589793238462643383279
48, 3.14159265358979323846264338327950288419716939937
'''

r = remote('140.110.112.29', 5130)
for x in range(5):
  r.recvline()

for x in range(100):
  r.recvline()
  s = r.recvline()
  s = s.split()
  num = int(s[2])
  temp = ans // (10 ** (150 - num))
  if(num != 31 and num != 48) :
    if(temp % 10 >= 5) :
      temp += 10
  temp //= 10
  temp = str(temp)
  a = "3." + temp[1:]
  r.sendline(a)
print r.recvline()
