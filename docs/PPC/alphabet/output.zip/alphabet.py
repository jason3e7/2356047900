from pwn import *

r = remote('140.110.112.29', 5128)
for x in range(3):
  r.recvline()

for x in range(100):
  r.recvline()
  s = r.recvline()
  s = s.split()  
  a = str(s[4].count(s[2]))
  r.sendline(a)
print r.recvline()
