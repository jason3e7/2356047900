from pwn import *

r = remote('140.110.112.29', 5125)
for x in range(5):
  r.recvline()

for x in range(100) :
  r.recvline()
  s = r.recvline()
  search = re.search(': (\w*)', s, re.IGNORECASE)
  s = search.group(1)
  r.recvuntil(':', drop=True) 

  s = s[::-1]
  count = 0
  i = 0
  base = 1
  for c in s :
    if('a' <= c and c <= 'z') :
      count = count + (ord(c) * base)
      base = base * 256
      i = i + 1
  r.sendline(str(count))
print r.recvline()

'''
'spiderman' not same

---

from math import pow
count = count + (ord(x) * pow(base, i))

---

count = count + (ord(x) * base)
base = base * 256

'''