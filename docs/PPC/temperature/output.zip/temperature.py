from pwn import *

r = remote('140.110.112.29', 5127)
for x in range(5):
  r.recvline()

for x in range(100):
  r.recvline()
  s = r.recvline()
  r.recvuntil(':', drop=True) 

  search = re.search(': ([-]?\d*)', s, re.IGNORECASE)
  s = search.group(1)

  # s = "10", -110/9
  a = (int(s) - 32) * 5
  a = str(a) + "/9"
  r.sendline(a)
print r.recvline()
