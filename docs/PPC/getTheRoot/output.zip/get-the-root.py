from pwn import *

def getNum(q, x) :
  s = q.split()
  s = s[2:]
  s = s[::-1]
  
  base = 0
  c = 0
  for i in s :
    c = c + (int(i) * (x ** base))
    base += 1
  return c

def findNum(q) :
  for i in range(-100, 100, 1) :
    if(getNum(q, i) == 0) :
      return i
  return 0

r = remote('140.110.112.29', 5122)
for x in range(5):
  r.recvline()

for x in range(100):
  r.recvline()
  s = r.recvline()
  ans = findNum(s)
  r.recvuntil('root :')
  r.sendline(str(ans))
print r.recvline()
