from pwn import *
import re

r = remote('140.110.112.29', 5132)
for x in range(5):
  r.recvline()

# max on 10000000000
bottom = 0
top = 10000000000

for x in range(100):
  for y in range(4):
    r.recvline()
  r.recvuntil('>') 
  r.sendline('4')
  r.recvuntil(':')
  guess = (bottom + top) / 2 
  r.sendline(str(guess))
  s = r.recvline()
  if (re.search('CTF', s) != None) :
    print x
    print guess
    print s
    break
  if (re.search('too much', s) != None) :
    top = guess
  if (re.search('not enough', s) != None) :
    bottom = guess
