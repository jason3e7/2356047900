from pwn import *

def getNum(length) :
  b = 1
  for i in range(length - 1):
    b *= 10
    b += 1

  while True :
    c = 0
    temp = b
    flag = 1
    while(temp > 0) : 
      if(temp % 10 == 0) :
        flag = 0  
        break
      c += (temp % 10)
      temp /= 10
    if(flag == 1 and (b % c == 0)) :
  	    return b
    b += 1

r = remote('140.110.112.29', 5129)
for x in range(7):
  r.recvline()

for x in range(100):
  r.recvline()
  s = r.recvline()
  s = s.split()
  a = str(getNum(int(s[2])))
  r.sendline(a)
print r.recvline()