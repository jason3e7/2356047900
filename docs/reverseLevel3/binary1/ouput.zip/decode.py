s = ""

flag = ""
for i in range(0, len(s), 2) : 
  shift = i / 2
  left = ((shift ^ 9) & 3)
  right = (8 - ((shift ^ 9) & 3))
  #print shift, left, right
  temp = int('0x'+s[i:i+2], 16)
  #print temp
  temp -= 8
  if (temp < 0) :
    temp += 256
  #print temp
  #print temp >> left & 255
  #print temp << right & 255
  temp = ((temp >> left & 255 | (temp << right & 255)) ^ shift)
  #print temp, chr(temp)
  flag += chr(temp)
print flag