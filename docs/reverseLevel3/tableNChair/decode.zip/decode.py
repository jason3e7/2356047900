s = ""
s1 = ""

flag = ""
for x in s1 :
  for y in range(1, 761, 2) :
    if (s[y] == x) :
      flag = flag + s[y-1] 
      break

print flag